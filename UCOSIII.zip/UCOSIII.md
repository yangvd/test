> #         **重庆交通大学信息科学与工程学院**
>
> #             **《嵌入式系统开发》课程**
>
> #                      作业报告（第x周）

**班 级： <span class="underline"> 通信工程2001班

**姓名-学号 ： <span class="underline"> 阎桂董-632007030622 </span>**

**实验项目名称： <span class="underline"> 作业题目 </span>**

**实验项目性质： <span class="underline"> 设计性 </span>**

**实验所属课程： <span class="underline">《嵌入式系统开发》 </span>**

**实验室(中心)： <span class="underline"> 南岸校区语音大楼 </span>**

**指 导 教 师 ： <span class="underline">娄路 </span>**

**完成时间： <span class="underline"> 2022</span> 年 <span class="underline"> 11</span> 月 <span class="underline"> 7</span> 日**

------

<div STYLE="page-break-after: always;"></div>

<div STYLE="page-break-after: always;"></div>

**一、实验内容和任务**

嵌入式RTOS编程

**二、实验要求**

1\. 分组要求：每个学生独立完成，即1人1组。

2\. 程序及报告文档要求：具有较好的可读性，如叙述准确、标注明确、截图清晰等。

3.项目代码上传github，同时把项目完整打包为zip文件，与实验报告（Markdown源码及PDF文件）、作业博客地址一起提交到学习通。

三. **实验过程介绍 **

学习嵌入式实时操作系统（RTOS）,以uc/OS为例，将其移植到stm32F103上，构建至少3个任务（task）:其中两个task分别以1s和3s周期对LED灯进行点亮-熄灭的控制；另外一个task以2s周期通过串口发送“hello uc/OS! 欢迎来到RTOS多任务环境！”。记录详细的移植过程。

# 一、用CubeMX建立HAL库

## 1、配置RCC、SYS、USART1、工程等等

![image-20221107212300984](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212300984.png)

![image-20221107212328520](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212328520.png)

![image-20221107212404565](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212404565.png)

![image-20221107212457743](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212457743.png)

![image-20221107212552526](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212552526.png)

![image-20221107212607137](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212607137.png)

## 2、代码

点击生成代码

在main函数中的while循环里添加语句

```
HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);
		HAL_Delay(500);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);
		HAL_Delay(500);
```

![image-20221107212921344](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107212921344.png)

![image-20221107213332540](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107213332540.png)

烧录成功后，可看到以下效果

![img](file:///C:\Users\ASUS\Documents\Tencent Files\1943459926\Image\C2C\83F534B838631FE3010A48697C60437E.gif)

# 二、uCOSIII源码

链接：https://pan.baidu.com/s/1iXrFhZsH68bNyRiTKf01NQ 
提取码：9s9b

下载后打开目录

![image-20221107214339830](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107214339830.png)

# 三、准备

1.为uC-BSP文件夹新建bsp.c和bsp.h文件
2.给文件夹uC-CONFIG添加以下文件

![image-20221107214648669](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107214648669.png)

![image-20221107214707400](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107214707400.png)

3.将uCOS相关文件复制到HAL工程的MDK-ARM文件夹下

![image-20221107214734791](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107214734791.png)

![image-20221107214836054](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107214836054.png)

# 四、移植

## 1.将uCOS文件添加到项目

点击Manage Project Items

![image-20221107215101466](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215101466.png)

为项目新建文件夹如下

![image-20221107215234108](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215234108.png)

分别给新增的文件夹添加文件

点击CPU–>Add Files…，选中以下文件，Add

![image-20221107215517452](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215517452.png)

![image-20221107215529897](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215529897.png)

![image-20221107215738470](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215738470.png)

添加好的CPU文件

![image-20221107215812670](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215812670.png)

点击LIB–>Add Files…，选中以下文件，Add

![image-20221107215933333](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107215933333.png)

![image-20221107220057548](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107220057548.png)

![image-20221107220110624](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107220110624.png)

点击PORT–>Add Files…，选中以下文件，Add

![image-20221107220837556](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107220837556.png)

添加好的PORT文件

![image-20221107220914829](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107220914829.png)

点击SOURCE–>Add Files…，选中以下文件，Add

![image-20221107221015793](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221015793.png)

添加好的SOURCE文件

![image-20221107221041483](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221041483.png)

点击CONFIG–>Add Files…，选中以下文件，Add

![image-20221107221124451](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221124451.png)

![image-20221107221137190](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221137190.png)

点击BSP–>Add Files…，选中以下文件，Add

![image-20221107221213203](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221213203.png)

![image-20221107221224430](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221224430.png)

**最后点击OK确定！**

此时项目结构会发生变化

![image-20221107221455452](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221455452.png)

导入文件路径

![image-20221107221817495](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107221817495.png)

点击OK

## 2.为bsp.c和bsp.h添加代码

找到BSP下的bsp.c和bsp.h文件

添加代码如下：

bsp.h

```
// bsp.h
#ifndef  __BSP_H__
#define  __BSP_H__

#include "stm32f1xx_hal.h"

void BSP_Init(void);

#endif

```

![image-20221107222006799](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222006799.png)

bsp.c

```
// bsp.c
#include "includes.h"

#define  DWT_CR      *(CPU_REG32 *)0xE0001000
#define  DWT_CYCCNT  *(CPU_REG32 *)0xE0001004
#define  DEM_CR      *(CPU_REG32 *)0xE000EDFC
#define  DBGMCU_CR   *(CPU_REG32 *)0xE0042004

#define  DEM_CR_TRCENA                   (1 << 24)
#define  DWT_CR_CYCCNTENA                (1 <<  0)

CPU_INT32U  BSP_CPU_ClkFreq (void)
{
    return HAL_RCC_GetHCLKFreq();
}

void BSP_Tick_Init(void)
{
	CPU_INT32U cpu_clk_freq;
	CPU_INT32U cnts;
	cpu_clk_freq = BSP_CPU_ClkFreq();
	
	#if(OS_VERSION>=3000u)
		cnts = cpu_clk_freq/(CPU_INT32U)OSCfg_TickRate_Hz;
	#else
		cnts = cpu_clk_freq/(CPU_INT32U)OS_TICKS_PER_SEC;
	#endif
	OS_CPU_SysTickInit(cnts);
}



void BSP_Init(void)
{
	BSP_Tick_Init();
	MX_GPIO_Init();
}


#if (CPU_CFG_TS_TMR_EN == DEF_ENABLED)
void  CPU_TS_TmrInit (void)
{
    CPU_INT32U  cpu_clk_freq_hz;


    DEM_CR         |= (CPU_INT32U)DEM_CR_TRCENA;                /* Enable Cortex-M3's DWT CYCCNT reg.                   */
    DWT_CYCCNT      = (CPU_INT32U)0u;
    DWT_CR         |= (CPU_INT32U)DWT_CR_CYCCNTENA;

    cpu_clk_freq_hz = BSP_CPU_ClkFreq();
    CPU_TS_TmrFreqSet(cpu_clk_freq_hz);
}
#endif


#if (CPU_CFG_TS_TMR_EN == DEF_ENABLED)
CPU_TS_TMR  CPU_TS_TmrRd (void)
{
    return ((CPU_TS_TMR)DWT_CYCCNT);
}
#endif


#if (CPU_CFG_TS_32_EN == DEF_ENABLED)
CPU_INT64U  CPU_TS32_to_uSec (CPU_TS32  ts_cnts)
{
	CPU_INT64U  ts_us;
  CPU_INT64U  fclk_freq;

 
  fclk_freq = BSP_CPU_ClkFreq();
  ts_us     = ts_cnts / (fclk_freq / DEF_TIME_NBR_uS_PER_SEC);

  return (ts_us);
}
#endif
 
 
#if (CPU_CFG_TS_64_EN == DEF_ENABLED)
CPU_INT64U  CPU_TS64_to_uSec (CPU_TS64  ts_cnts)
{
	CPU_INT64U  ts_us;
	CPU_INT64U  fclk_freq;


  fclk_freq = BSP_CPU_ClkFreq();
  ts_us     = ts_cnts / (fclk_freq / DEF_TIME_NBR_uS_PER_SEC);
	
  return (ts_us);
}
#endif

```

![image-20221107222053847](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222053847.png)

## 3.修改main.c文件代码

```
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "gpio.h"
#include "usart.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <includes.h>
#include "stm32f1xx_hal.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* 任务优先级 */
#define START_TASK_PRIO		3
#define LED0_TASK_PRIO		4
#define MSG_TASK_PRIO		5

/* 任务堆栈大小	*/
#define START_STK_SIZE 		64
#define LED0_STK_SIZE 		64
#define MSG_STK_SIZE 		64//任务堆大小过大会报错，可以试着改小一点

/* 任务栈 */	
CPU_STK START_TASK_STK[START_STK_SIZE];
CPU_STK LED0_TASK_STK[LED0_STK_SIZE];
CPU_STK MSG_TASK_STK[MSG_STK_SIZE];
/* 任务控制块 */
OS_TCB StartTaskTCB;
OS_TCB Led0TaskTCB;
OS_TCB MsgTaskTCB;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* 任务函数定义 */
void start_task(void *p_arg);
static  void  AppTaskCreate(void);
static  void  AppObjCreate(void);
static  void  led_pc13(void *p_arg);
static  void  send_msg(void *p_arg);
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /**Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
	OS_ERR  err;
	OSInit(&err);
  HAL_Init();
	SystemClock_Config();
	//MX_GPIO_Init(); 这个在BSP的初始化里也会初始化
  MX_USART1_UART_Init();	
	/* 创建任务 */
	OSTaskCreate((OS_TCB     *)&StartTaskTCB,                /* Create the start task                                */
				 (CPU_CHAR   *)"start task",
				 (OS_TASK_PTR ) start_task,
				 (void       *) 0,
				 (OS_PRIO     ) START_TASK_PRIO,
				 (CPU_STK    *)&START_TASK_STK[0],
				 (CPU_STK_SIZE) START_STK_SIZE/10,
				 (CPU_STK_SIZE) START_STK_SIZE,
				 (OS_MSG_QTY  ) 0,
				 (OS_TICK     ) 0,
				 (void       *) 0,
				 (OS_OPT      )(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
				 (OS_ERR     *)&err);
	/* 启动多任务系统，控制权交给uC/OS-III */
	OSStart(&err);            /* Start multitasking (i.e. give control to uC/OS-III). */
               
}


void start_task(void *p_arg)
{
	OS_ERR err;
	CPU_SR_ALLOC();
	p_arg = p_arg;
	
	/* YangJie add 2021.05.20*/
  BSP_Init();                                                   /* Initialize BSP functions */
  //CPU_Init();
  //Mem_Init();                                                 /* Initialize Memory Management Module */

#if OS_CFG_STAT_TASK_EN > 0u
   OSStatTaskCPUUsageInit(&err);  		//统计任务                
#endif
	
#ifdef CPU_CFG_INT_DIS_MEAS_EN			//如果使能了测量中断关闭时间
    CPU_IntDisMeasMaxCurReset();	
#endif

#if	OS_CFG_SCHED_ROUND_ROBIN_EN  		//当使用时间片轮转的时候
	 //使能时间片轮转调度功能,时间片长度为1个系统时钟节拍，既1*5=5ms
	OSSchedRoundRobinCfg(DEF_ENABLED,1,&err);  
#endif		
	
	OS_CRITICAL_ENTER();	//进入临界区
	/* 创建LED0任务 */
	OSTaskCreate((OS_TCB 	* )&Led0TaskTCB,		
				 (CPU_CHAR	* )"led_pc13", 		
                 (OS_TASK_PTR )led_pc13, 			
                 (void		* )0,					
                 (OS_PRIO	  )LED0_TASK_PRIO,     
                 (CPU_STK   * )&LED0_TASK_STK[0],	
                 (CPU_STK_SIZE)LED0_STK_SIZE/10,	
                 (CPU_STK_SIZE)LED0_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,					
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR,
                 (OS_ERR 	* )&err);				
				 
	/* 创建LED1任务 */
	OSTaskCreate((OS_TCB 	* )&MsgTaskTCB,		
				 (CPU_CHAR	* )"send_msg", 		
                 (OS_TASK_PTR )send_msg, 			
                 (void		* )0,					
                 (OS_PRIO	  )MSG_TASK_PRIO,     	
                 (CPU_STK   * )&MSG_TASK_STK[0],	
                 (CPU_STK_SIZE)MSG_STK_SIZE/10,	
                 (CPU_STK_SIZE)MSG_STK_SIZE,		
                 (OS_MSG_QTY  )0,					
                 (OS_TICK	  )0,					
                 (void   	* )0,				
                 (OS_OPT      )OS_OPT_TASK_STK_CHK|OS_OPT_TASK_STK_CLR, 
                 (OS_ERR 	* )&err);
				 
	OS_TaskSuspend((OS_TCB*)&StartTaskTCB,&err);		//挂起开始任务			 
	OS_CRITICAL_EXIT();	//进入临界区
}
/**
  * 函数功能: 启动任务函数体。
  * 输入参数: p_arg 是在创建该任务时传递的形参
  * 返 回 值: 无
  * 说    明：无
  */
static  void  led_pc13 (void *p_arg)
{
  OS_ERR      err;

  (void)p_arg;

  BSP_Init();                                                 /* Initialize BSP functions                             */
  CPU_Init();

  Mem_Init();                                                 /* Initialize Memory Management Module                  */

#if OS_CFG_STAT_TASK_EN > 0u
  OSStatTaskCPUUsageInit(&err);                               /* Compute CPU capacity with no task running            */
#endif

  CPU_IntDisMeasMaxCurReset();

  AppTaskCreate();                                            /* Create Application Tasks                             */

  AppObjCreate();                                             /* Create Application Objects                           */

  while (DEF_TRUE)
  {
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_RESET);
		OSTimeDlyHMSM(0, 0, 0, 500,OS_OPT_TIME_HMSM_STRICT,&err);
		HAL_GPIO_WritePin(GPIOC,GPIO_PIN_13,GPIO_PIN_SET);
		OSTimeDlyHMSM(0, 0, 0, 500,OS_OPT_TIME_HMSM_STRICT,&err);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}
static  void  send_msg (void *p_arg)
{
  OS_ERR      err;

  (void)p_arg;

  BSP_Init();                                                 /* Initialize BSP functions                             */
  CPU_Init();

  Mem_Init();                                                 /* Initialize Memory Management Module                  */

#if OS_CFG_STAT_TASK_EN > 0u
  OSStatTaskCPUUsageInit(&err);                               /* Compute CPU capacity with no task running            */
#endif

  CPU_IntDisMeasMaxCurReset();

  AppTaskCreate();                                            /* Create Application Tasks                             */

  AppObjCreate();                                             /* Create Application Objects                           */

  while (DEF_TRUE)
  {
			printf("hello world \r\n");
		OSTimeDlyHMSM(0, 0, 0, 500,OS_OPT_TIME_HMSM_STRICT,&err);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}


/* USER CODE BEGIN 4 */
/**
  * 函数功能: 创建应用任务
  * 输入参数: p_arg 是在创建该任务时传递的形参
  * 返 回 值: 无
  * 说    明：无
  */
static  void  AppTaskCreate (void)
{
  
}


/**
  * 函数功能: uCOSIII内核对象创建
  * 输入参数: 无
  * 返 回 值: 无
  * 说    明：无
  */
static  void  AppObjCreate (void)
{

}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/


```

![image-20221107222238335](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222238335.png)

## 4.修改其余文件部分代码

找到文件startup_…

在以下位置处将PendSV_Handler和SysTick_Handler改为OS_CPU_PendSVHandler和OS_CPU_SysTickHandler

![image-20221107222435868](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222435868.png)

![image-20221107222543472](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222543472.png)

找到文件app_cfg.h

ENABLED改为DISABLED

![image-20221107222719711](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222719711.png)

将BSP_Ser_Printf改为(void)

![image-20221107222729783](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222729783.png)

找到文件includes.h

\#include <bsp.h>处添加

```
#include"gpio.h"
#include"app_cfg.h"
```

![image-20221107222828329](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222828329.png)

将此处代码改为

```
#include  <stm32f1xx_hal.h>
```

![image-20221107222923093](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107222923093.png)

找到lib_cfg.h

此处修改为5

![image-20221107223206568](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107223206568.png)

由于我们使用了printf函数，需要在usart.c文件中添加以下代码完成printf重定向

![image-20221107223231246](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107223231246.png)

**此处要加#include <stdio.h>,否则会报错**

## 5.参数配置

![image-20221107223304443](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107223304443.png)

![image-20221107223316908](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107223316908.png)

到这里，该做的都做了，可以编译了，编译没有错误，

![image-20221107230042820](C:\Users\ASUS\AppData\Roaming\Typora\typora-user-images\image-20221107230042820.png)

# 五.运行

板子上运行效果如下

![img](file:///C:\Users\ASUS\Documents\Tencent Files\1943459926\Image\C2C\7FB72764241C991110EFFABFFD08C311.gif)

# 总结

在文件添加中小心小心一定要小心，不然可能复查
